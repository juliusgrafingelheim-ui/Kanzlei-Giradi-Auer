import { getFAQsByCategories, PAGE_FAQ_CATEGORIES } from "../faqData";
import { usePageContent } from "../storyblok";
import { ParallaxHero } from "../ParallaxHero";
import { GoogleReviewSingle } from "../GoogleReviews";
import { ArrowRight, Star, Heart, Users, Baby, PartyPopper } from "lucide-react";
import { useLanguage } from "../LanguageContext";
import { SectionReveal } from "../SectionReveal";
import { SEO } from "../SEO";
import { Lightbox, useLightbox } from "../Lightbox";
import { motion } from "motion/react";
import { ImageWithFallback } from "../figma/ImageWithFallback";
import { useContactModal } from "../ContactModal";
import { useShuffledGallery } from "../useShuffledGallery";
import { useImages } from "../useImages";
import { MasonryGrid } from "../MasonryGrid";
import { FAQSection } from "../FAQSection";

const IMAGES = {
  hero: "https://ik.imagekit.io/r2yqrg6np/Tiere/20251019_Hundeshooting-4431_(WebRes).jpg?updatedAt=1772999913745",
  couple: "https://ik.imagekit.io/r2yqrg6np/Wedding/Getting%20Ready/20251004_8D2A0221_(WebRes).jpg?updatedAt=1773002917508",
  family: "https://ik.imagekit.io/r2yqrg6np/Wedding/Paarfotos/250830_LJ_153525_0450(LowRes).jpg?updatedAt=1773007047995",
  baptism: "https://ik.imagekit.io/r2yqrg6np/Other/7561IG.jpg?updatedAt=1773014105229",
  coupleSunset: "https://images.unsplash.com/photo-1769050349380-7ee061d43ef9?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb3VwbGUlMjBwb3J0cmFpdCUyMHN1bnNldCUyMHJvbWFudGljJTIwb3V0ZG9vcnN8ZW58MXx8fHwxNzcyOTk3NTMzfDA&ixlib=rb-4.1.0&q=80&w=1080",
  familyAutumn: "https://images.unsplash.com/photo-1768509196851-16084e78f6ac?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmYW1pbHklMjBwb3J0cmFpdCUyMG91dGRvb3IlMjBhdXR1bW4lMjBuYXR1cmFsfGVufDF8fHx8MTc3Mjk5NzUzM3ww&ixlib=rb-4.1.0&q=80&w=1080",
  baptismChurch: "https://images.unsplash.com/photo-1765947386414-5e63c7887830?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxiYWJ5JTIwYmFwdGlzbSUyMGNocmlzdGVuaW5nJTIwY2VyZW1vbnklMjBjaHVyY2h8ZW58MXx8fHwxNzcyOTk3NTM0fDA&ixlib=rb-4.1.0&q=80&w=1080",
  coupleLaughing: "https://images.unsplash.com/photo-1768468104186-368aeb7a266a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb3VwbGUlMjBsYXVnaGluZyUyMG91dGRvb3IlMjBlbmdhZ2VtZW50JTIwcGhvdG98ZW58MXx8fHwxNzcyOTk3NTM0fDA&ixlib=rb-4.1.0&q=80&w=1080",
};

export function PortraitPage() {
  const { t, lang } = useLanguage();
  const { open, index, openLightbox, closeLightbox } = useLightbox();
  const { openContact } = useContactModal();
  const { getImagesForPage } = useImages();
  const { getText, getAsset, getIcon } = usePageContent("portrait", lang);

  const seo = lang === "de"
    ? {
        title: "Portrait, Couple Shooting & Familienfotografie Innsbruck | Mario Schubert",
        description: "Couple Shootings, Familienfotografie, Taufe und private Anlaesse in Innsbruck, Tirol und Bayern. Authentische, emotionale Bilder. Jetzt anfragen!",
        keywords: "Couple Shooting Innsbruck, Familienfotografie Tirol, Portraitfotografie Bayern, Taufe Fotograf Muenchen, Familienshooting Alpen",
      }
    : {
        title: "Portrait, Couple Shooting & Family Photography Innsbruck | Mario Schubert",
        description: "Couple shootings, family photography, baptism and private occasions in Innsbruck, Tyrol and Bavaria. Authentic, emotional images. Inquire now!",
        keywords: "couple shooting Innsbruck, family photography Tyrol, portrait photography Bavaria, baptism photographer Munich, family shooting Alps",
      };

  const categories = [
    {
      title: getText("couple_title", t.portrait.coupleTitle),
      text: getText("couple_text", t.portrait.coupleText),
      image: getAsset("couple_image", IMAGES.couple),
      imageAlt: "Verliebtes Paar beim Couple Shooting in den Tiroler Alpen – Paarfotograf Mario Schubert Innsbruck",
    },
    {
      title: getText("family_title", t.portrait.familyTitle),
      text: getText("family_text", t.portrait.familyText),
      image: getAsset("family_image", IMAGES.family),
      imageAlt: "Natuerliches Familienshooting Outdoor – Familienfotograf Innsbruck Tirol",
    },
    {
      title: getText("private_title", t.portrait.privateTitle),
      text: getText("private_text", t.portrait.privateText),
      image: getAsset("baptism_image", IMAGES.baptism),
      imageAlt: "Taufe Zeremonie Fotografie – Eventfotograf Mario Schubert Bayern und Tirol",
    },
  ];

  // Pull portrait images from Google Sheet (ImageKit "Other" folder → page "portrait")
  // Falls back to hardcoded Unsplash images if API unavailable
  const fallbackImages = [
    { src: IMAGES.coupleSunset, alt: "Romantisches Couple Shooting bei Sonnenuntergang – Paarfotograf Tirol" },
    { src: IMAGES.family, alt: "Natuerliches Familienshooting Outdoor – Familienfotograf Innsbruck" },
    { src: IMAGES.baptismChurch, alt: "Taufe Zeremonie in der Kirche – Taufe Fotograf Innsbruck" },
    { src: IMAGES.coupleLaughing, alt: "Lachendes Paar beim Engagement Shooting – Couple Fotograf Bayern" },
    { src: IMAGES.familyAutumn, alt: "Familienportrait Herbst Outdoor – Familienfotografie Tirol" },
    { src: IMAGES.couple, alt: "Romantisches Paar Outdoor in den Alpen – Paarshooting Mario Schubert" },
    { src: IMAGES.hero, alt: "Couple Shooting Outdoor – Portrait und Paarfotografie Innsbruck" },
    { src: IMAGES.baptism, alt: "Taufe Fotografie – Babyfotograf und Eventfotograf Tirol" },
  ];

  const apiImages = getImagesForPage("portrait", undefined, lang);
  const rawGalleryImages = apiImages.length > 0 ? apiImages : fallbackImages;
  const galleryImages = useShuffledGallery(rawGalleryImages);

  return (
    <>
      <SEO
        title={seo.title}
        description={seo.description}
        canonical="/portrait"
        keywords={seo.keywords}
        lang={lang}
        ogImage={getAsset("hero_image", IMAGES.hero)}
      />

      {/* Hero with Parallax */}
      <ParallaxHero
        imageSrc={getAsset("hero_image", IMAGES.hero)}
        imageAlt="Romantisches Couple Shooting Outdoor – Portrait und Paarfotografie in Innsbruck, Tirol von Mario Schubert"
        preTitle={getText("hero_title", t.portrait.heroTitle)}
        title={getText("hero_subtitle", t.portrait.heroSubtitle)}
      />

      {/* Intro */}
      <section className="py-20 md:py-28 px-4">
        <div className="max-w-3xl mx-auto text-center">
          <SectionReveal>
            <p
              className="text-black/70 text-[1rem] md:text-[1.1rem]"
              style={{ lineHeight: 1.9, fontWeight: 300 }}
            >
              {getText("intro", t.portrait.intro)}
            </p>
          </SectionReveal>
        </div>
      </section>

      {/* Categories */}
      {categories.map((cat, i) => (
        <section
          key={cat.title}
          className={`py-24 md:py-32 px-4 ${i % 2 === 1 ? "bg-[#f8f7f5]" : ""}`}
        >
          <div className="max-w-7xl mx-auto">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-20 items-center">
              <SectionReveal>
                <div className={i % 2 === 1 ? "lg:order-2" : ""}>
                  <h2
                    style={{
                      fontFamily: "'Cormorant Garamond', serif",
                      fontSize: "clamp(2rem, 4vw, 3rem)",
                      fontWeight: 600,
                      lineHeight: 1.1,
                      marginBottom: "1.5rem",
                    }}
                  >
                    {cat.title}
                  </h2>
                  <p
                    className="text-black/70 text-[0.9rem] mb-6"
                    style={{ lineHeight: 1.8, fontWeight: 300 }}
                  >
                    {cat.text}
                  </p>
                  <button
                    onClick={() => openContact("portrait")}
                    className="inline-flex items-center gap-2 text-[0.8rem] tracking-[0.12em] uppercase text-black bg-transparent cursor-pointer hover:opacity-70 transition-opacity border-none p-0"
                    style={{ fontWeight: 400, borderBottom: "1px solid rgba(0,0,0,0.3)", paddingBottom: "4px" }}
                  >
                    {lang === "de" ? "Jetzt anfragen" : "Inquire now"} →
                  </button>
                </div>
              </SectionReveal>
              <SectionReveal delay={0.2}>
                <div className={i % 2 === 1 ? "lg:order-1" : ""}>
                  <motion.div
                    whileHover={{ scale: 1.03 }}
                    transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
                    className="overflow-hidden"
                  >
                    <ImageWithFallback
                      src={cat.image}
                      alt={cat.imageAlt}
                      className="w-full aspect-[4/3] object-cover"
                    />
                  </motion.div>
                </div>
              </SectionReveal>
            </div>
          </div>
        </section>
      ))}

      {/* Pricing → replaced with friendly "on request" section */}
      <section className="py-24 md:py-32 bg-[#f8f7f5] px-4">
        <div className="max-w-3xl mx-auto text-center">
          <SectionReveal>
            <p
              className="text-[0.75rem] tracking-[0.3em] uppercase text-black/55 mb-4"
              style={{ fontWeight: 400 }}
            >
              {getText("pricing_pretitle", lang === "de" ? "INDIVIDUELL & PERSÖNLICH" : "INDIVIDUAL & PERSONAL")}
            </p>
            <h2
              style={{
                fontFamily: "'Cormorant Garamond', serif",
                fontSize: "clamp(2rem, 4vw, 3rem)",
                fontWeight: 300,
                marginBottom: "1.5rem",
              }}
            >
              {getText("pricing_title", lang === "de" ? "Jedes Shooting ist einzigartig" : "Every shoot is unique")}
            </h2>
            <p
              className="text-black/70 text-[0.92rem] mb-4 max-w-2xl mx-auto"
              style={{ lineHeight: 1.9, fontWeight: 300 }}
            >
              {getText("pricing_text", lang === "de"
                ? "Ob Couple Shooting, Familienportrait, Taufe oder ein ganz besonderer Anlass – ich schnüre für jedes Shooting ein individuelles Angebot, das perfekt zu euch passt. Keine starren Pakete, sondern genau das, was ihr braucht."
                : "Whether it's a couple shoot, family portrait, baptism or a special occasion – I create a custom offer for every shoot that's perfectly tailored to you. No rigid packages, just exactly what you need.")}
            </p>
            <p
              className="text-black/55 text-[0.85rem] mb-10 max-w-xl mx-auto"
              style={{ lineHeight: 1.8, fontWeight: 300, fontStyle: "italic" }}
            >
              {getText("pricing_note", lang === "de"
                ? "Schreibt mir einfach – ich melde mich innerhalb von 24 Stunden mit einem unverbindlichen Angebot bei euch."
                : "Just send me a message – I'll get back to you within 24 hours with a non-binding offer.")}
            </p>
            <button
              onClick={() => openContact("portrait")}
              className="inline-flex items-center gap-2 text-black border border-black px-10 py-4 text-[0.8rem] tracking-[0.15em] uppercase bg-transparent cursor-pointer hover:bg-black hover:text-white transition-all duration-300"
              style={{ fontWeight: 400 }}
            >
              {getText("pricing_cta", lang === "de" ? "Unverbindlich anfragen" : "Inquire now")}
              <ArrowRight size={14} />
            </button>
          </SectionReveal>
        </div>
      </section>

      {/* Perfect For */}
      <section className="py-24 md:py-32 px-4">
        <div className="max-w-5xl mx-auto">
          <SectionReveal>
            <div className="text-center mb-16">
              <h2
                style={{
                  fontFamily: "'Cormorant Garamond', serif",
                  fontSize: "clamp(2rem, 4vw, 3rem)",
                  fontWeight: 300,
                }}
              >
                {getText("occasions_title", lang === "de" ? "Perfekt für jeden Anlass" : "Perfect for every occasion")}
              </h2>
            </div>
          </SectionReveal>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {(() => {
              const OccIcon1 = getIcon("occasion1_icon", Heart);
              const OccIcon2 = getIcon("occasion2_icon", Users);
              const OccIcon3 = getIcon("occasion3_icon", Baby);
              const OccIcon4 = getIcon("occasion4_icon", PartyPopper);
              return [
                { icon: OccIcon1, title: getText("occasion1_title", lang === "de" ? "Couple Shootings" : "Couple Shoots"), text: getText("occasion1_text", lang === "de" ? "Verlobung, Jahrestag oder einfach so" : "Engagement, anniversary or just because") },
                { icon: OccIcon2, title: getText("occasion2_title", lang === "de" ? "Familienshootings" : "Family Shoots"), text: getText("occasion2_text", lang === "de" ? "Mit Kindern, Großeltern oder der ganzen Bande" : "With kids, grandparents or the whole gang") },
                { icon: OccIcon3, title: getText("occasion3_title", lang === "de" ? "Taufe & Baby" : "Baptism & Baby"), text: getText("occasion3_text", lang === "de" ? "Die ersten Monate festhalten" : "Capture the first months") },
                { icon: OccIcon4, title: getText("occasion4_title", lang === "de" ? "Events & Feiern" : "Events & Parties"), text: getText("occasion4_text", lang === "de" ? "Geburtstage, Jubiläen, Firmenfeiern" : "Birthdays, anniversaries, corporate events") },
              ];
            })().map((item, i) => (
              <SectionReveal key={item.title} delay={i * 0.1}>
                <div className="text-center">
                  <div className="w-14 h-14 mx-auto mb-4 border border-black/10 flex items-center justify-center">
                    <item.icon size={20} className="text-black/50" />
                  </div>
                  <h3
                    className="mb-1"
                    style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: "1.15rem", fontWeight: 600 }}
                  >
                    {item.title}
                  </h3>
                  <p className="text-black/60 text-[0.8rem]" style={{ lineHeight: 1.6, fontWeight: 300 }}>
                    {item.text}
                  </p>
                </div>
              </SectionReveal>
            ))}
          </div>
        </div>
      </section>

      {/* Gallery */}
      <section className="py-24 md:py-32 px-4">
        <div className="max-w-7xl mx-auto">
          <SectionReveal>
            <h2
              className="text-center mb-16"
              style={{
                fontFamily: "'Cormorant Garamond', serif",
                fontSize: "clamp(2rem, 4vw, 3rem)",
                fontWeight: 300,
                letterSpacing: "0.1em",
              }}
            >
              {getText("gallery_title", "GET INSPIRED")}
            </h2>
          </SectionReveal>

          <MasonryGrid
            images={galleryImages}
            openLightbox={openLightbox}
            initialPageSize={galleryImages.length}
          />
        </div>
      </section>

      <Lightbox
        images={galleryImages}
        initialIndex={index}
        open={open}
        onClose={closeLightbox}
      />

      {/* Testimonial */}
      <GoogleReviewSingle bg="cream" reviewIndex={4} />

      {/* Portrait FAQ */}
      <FAQSection
        categories={getFAQsByCategories(PAGE_FAQ_CATEGORIES.portrait)}
        title={{ de: "Häufige Fragen zu Portrait & Shootings", en: "Portrait & Shooting FAQ" }}
      />

      {/* CTA */}
      <section className="py-24 md:py-32 bg-black text-white">
        <div className="max-w-3xl mx-auto text-center px-4">
          <SectionReveal>
            <h2
              style={{
                fontFamily: "'Cormorant Garamond', serif",
                fontSize: "clamp(2rem, 5vw, 3.5rem)",
                fontWeight: 300,
                lineHeight: 1.1,
                marginBottom: "1.5rem",
              }}
            >
              {getText("cta_title", t.portrait.ctaTitle)}
            </h2>
            <p
              className="text-white/50 text-[0.9rem] mb-10"
              style={{ lineHeight: 1.8, fontWeight: 300 }}
            >
              {getText("cta_text", t.portrait.ctaText)}
            </p>
            <button
              onClick={() => openContact("portrait")}
              className="inline-flex items-center gap-2 text-white border border-white/40 px-8 py-3 text-[0.8rem] tracking-[0.15em] uppercase bg-transparent cursor-pointer hover:bg-white hover:text-black transition-all duration-300"
              style={{ fontWeight: 400 }}
            >
              {getText("cta_button", t.portrait.ctaButton)}
              <ArrowRight size={14} />
            </button>
          </SectionReveal>
        </div>
      </section>
    </>
  );
}