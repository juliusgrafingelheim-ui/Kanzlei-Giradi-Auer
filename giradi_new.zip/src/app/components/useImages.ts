import { useState, useEffect, useMemo } from "react";
import { fetchStoryblokStories } from "./storyblok/storyblok-api";
import { isStoryblokConfigured } from "./storyblok/storyblok-init";

/**
 * Hook to fetch gallery images.
 *
 * Priority:
 * 1. localStorage cache (5 min)
 * 2. Storyblok CMS (if configured via VITE_STORYBLOK_TOKEN)
 * 3. Google Sheets API (legacy fallback via /api/get-images)
 * 4. Hardcoded fallback data
 */

// ── Types ──
export interface ImageEntry {
  page: string;
  category: string;
  src: string;
  altDe: string;
  altEn: string;
}

interface ImagesState {
  images: ImageEntry[];
  loading: boolean;
  error: string | null;
}

const CACHE_KEY = "marioschub_images";
const CACHE_DURATION = 5 * 60 * 1000; // 5 minutes (matches API cache)
const CACHE_BUST_KEY = "marioschub_images_bust"; // timestamp to bust CDN cache after sync

// ── Helper to generate entries ──
function w(category: string, src: string, altDe: string, altEn: string): ImageEntry {
  return { page: "hochzeit", category, src, altDe, altEn };
}

// ── Fallback data: all current gallery images ──
const FALLBACK_IMAGES: ImageEntry[] = [
  // ═══════════════════════════════════════════════
  // HOCHZEIT – Standesamt (24 Bilder)
  // ═══════════════════════════════════════════════
  w("standesamt", "https://ik.imagekit.io/r2yqrg6np/Wedding/Standesamt/20251004_8D2A9760_(WebRes).jpg?updatedAt=1773002603723", "Standesamtliche Trauung – Hochzeitsfotografie Innsbruck", "Civil ceremony – Wedding photography Innsbruck"),
  w("standesamt", "https://ik.imagekit.io/r2yqrg6np/Wedding/Standesamt/20251004_R52_0657_(WebRes).jpg?updatedAt=1773002603507", "Standesamt Hochzeit – Hochzeitsfotograf Tirol", "Civil wedding – Wedding photographer Tyrol"),
  w("standesamt", "https://ik.imagekit.io/r2yqrg6np/Wedding/Standesamt/20251004_8D2A9840_(WebRes).jpg?updatedAt=1773002603440", "Standesamtliche Trauung Innsbruck – Mario Schubert Fotografie", "Civil ceremony Innsbruck – Mario Schubert Photography"),
  w("standesamt", "https://ik.imagekit.io/r2yqrg6np/Wedding/Standesamt/20251004_R52_0061_(WebRes).jpg?updatedAt=1773002603431", "Standesamt Zeremonie – Hochzeitsfotograf Innsbruck", "Civil ceremony – Wedding photographer Innsbruck"),
  w("standesamt", "https://ik.imagekit.io/r2yqrg6np/Wedding/Standesamt/20251004_R52_0329_(WebRes).jpg?updatedAt=1773002603319", "Standesamt Hochzeitsfotografie Tirol", "Civil wedding photography Tyrol"),
  w("standesamt", "https://ik.imagekit.io/r2yqrg6np/Wedding/Standesamt/20251004_R52_0507_(WebRes).jpg?updatedAt=1773002603115", "Standesamtliche Trauung Bayern – Mario Schubert", "Civil ceremony Bavaria – Mario Schubert"),
  w("standesamt", "https://ik.imagekit.io/r2yqrg6np/Wedding/Standesamt/20251004_R52_0048_(WebRes).jpg?updatedAt=1773002602938", "Standesamt Hochzeit Innsbruck Tirol", "Civil wedding Innsbruck Tyrol"),
  w("standesamt", "https://ik.imagekit.io/r2yqrg6np/Wedding/Standesamt/20251004_8D2A9815_(WebRes).jpg?updatedAt=1773002602780", "Standesamtliche Trauung – Hochzeitsfotografie Alpen", "Civil ceremony – Alpine wedding photography"),
  w("standesamt", "https://ik.imagekit.io/r2yqrg6np/Wedding/Standesamt/20251004_R52_0516_(WebRes).jpg?updatedAt=1773002602782", "Standesamt Detailfoto – Hochzeitsfotograf Mario Schubert", "Civil ceremony detail – Wedding photographer Mario Schubert"),
  w("standesamt", "https://ik.imagekit.io/r2yqrg6np/Wedding/Standesamt/20251004_R52_0513_(WebRes).jpg?updatedAt=1773002602700", "Standesamtliche Trauung – Hochzeitsfotografie Tirol", "Civil ceremony – Wedding photography Tyrol"),
  w("standesamt", "https://ik.imagekit.io/r2yqrg6np/Wedding/Standesamt/20251004_R52_0055_(WebRes).jpg?updatedAt=1773002602657", "Standesamt Hochzeit – Hochzeitsfotograf Innsbruck Tirol", "Civil wedding – Wedding photographer Innsbruck Tyrol"),
  w("standesamt", "https://ik.imagekit.io/r2yqrg6np/Wedding/Standesamt/20251004_R52_0140_(WebRes).jpg?updatedAt=1773002602654", "Standesamtliche Trauung – Hochzeitsfotografie Mario Schubert", "Civil ceremony – Mario Schubert Photography"),
  w("standesamt", "https://ik.imagekit.io/r2yqrg6np/Wedding/Standesamt/20251004_R52_0515_(WebRes).jpg?updatedAt=1773002601525", "Standesamt Hochzeitsfotografie Innsbruck", "Civil wedding photography Innsbruck"),
  w("standesamt", "https://ik.imagekit.io/r2yqrg6np/Wedding/Standesamt/20251004_8D2A9967_(WebRes).jpg?updatedAt=1773002601431", "Standesamtliche Trauung – Fotograf Tirol", "Civil ceremony – Photographer Tyrol"),
  w("standesamt", "https://ik.imagekit.io/r2yqrg6np/Wedding/Standesamt/20251004_R52_0116_(WebRes).jpg?updatedAt=1773002601390", "Standesamt Hochzeit – Hochzeitsfotograf Tirol Bayern", "Civil wedding – Wedding photographer Tyrol Bavaria"),
  w("standesamt", "https://ik.imagekit.io/r2yqrg6np/Wedding/Standesamt/20251004_R52_0143_(WebRes).jpg?updatedAt=1773002601164", "Standesamtliche Trauung Innsbruck – Hochzeitsfotografie", "Civil ceremony Innsbruck – Wedding photography"),
  w("standesamt", "https://ik.imagekit.io/r2yqrg6np/Wedding/Standesamt/20251004_R52_0739_(WebRes).jpg?updatedAt=1773002601144", "Standesamt Hochzeit Tirol – Mario Schubert Fotografie", "Civil wedding Tyrol – Mario Schubert Photography"),
  w("standesamt", "https://ik.imagekit.io/r2yqrg6np/Wedding/Standesamt/20251004_8D2A9645_(WebRes).jpg?updatedAt=1773002601006", "Standesamtliche Trauung – Hochzeitsfotograf Innsbruck", "Civil ceremony – Wedding photographer Innsbruck"),
  w("standesamt", "https://ik.imagekit.io/r2yqrg6np/Wedding/Standesamt/20251004_R52_0202_(WebRes).jpg?updatedAt=1773002601028", "Standesamt Hochzeitsfotografie – Mario Schubert Tirol", "Civil wedding photography – Mario Schubert Tyrol"),
  w("standesamt", "https://ik.imagekit.io/r2yqrg6np/Wedding/Standesamt/20251004_8D2A9629_(WebRes).jpg?updatedAt=1773002600772", "Standesamtliche Trauung Bayern – Hochzeitsfotografie", "Civil ceremony Bavaria – Wedding photography"),
  w("standesamt", "https://ik.imagekit.io/r2yqrg6np/Wedding/Standesamt/20251004_8D2A9587_(WebRes).jpg?updatedAt=1773002600759", "Standesamt Zeremonie – Hochzeitsfotograf Innsbruck Tirol", "Civil ceremony – Wedding photographer Innsbruck Tyrol"),
  w("standesamt", "https://ik.imagekit.io/r2yqrg6np/Wedding/Standesamt/20251004_R52_0180_(WebRes).jpg?updatedAt=1773002600191", "Standesamtliche Trauung – Hochzeitsfotografie Alpen Tirol", "Civil ceremony – Alpine wedding photography Tyrol"),
  w("standesamt", "https://ik.imagekit.io/r2yqrg6np/Wedding/Standesamt/20251004_8D2A9692_(WebRes).jpg?updatedAt=1773002600074", "Standesamt Hochzeit – Hochzeitsfotograf Mario Schubert", "Civil wedding – Wedding photographer Mario Schubert"),
  w("standesamt", "https://ik.imagekit.io/r2yqrg6np/Wedding/Standesamt/20251004_R52_0187_(WebRes).jpg?updatedAt=1773002600088", "Standesamtliche Trauung Innsbruck Tirol – Hochzeitsfotografie", "Civil ceremony Innsbruck Tyrol – Wedding photography"),

  // ═══════════════════════════════════════════════
  // HOCHZEIT – Getting Ready (25 Bilder)
  // ═══════════════════════════════════════════════
  w("getting-ready", "https://ik.imagekit.io/r2yqrg6np/Wedding/Getting%20Ready/20251004_8D2A0205_(WebRes).jpg?updatedAt=1773002918118", "Getting Ready – Hochzeitsfotografie Innsbruck", "Getting ready – Wedding photography Innsbruck"),
  w("getting-ready", "https://ik.imagekit.io/r2yqrg6np/Wedding/Getting%20Ready/20251004_8D2A0373_(WebRes).jpg?updatedAt=1773002917981", "Braut Getting Ready – Hochzeitsfotograf Tirol", "Bride getting ready – Wedding photographer Tyrol"),
  w("getting-ready", "https://ik.imagekit.io/r2yqrg6np/Wedding/Getting%20Ready/20251004_8D2A0411_(WebRes).jpg?updatedAt=1773002917972", "Getting Ready Details – Mario Schubert Fotografie", "Getting ready details – Mario Schubert Photography"),
  w("getting-ready", "https://ik.imagekit.io/r2yqrg6np/Wedding/Getting%20Ready/20251004_8D2A0527_(WebRes).jpg?updatedAt=1773002917902", "Hochzeit Getting Ready – Hochzeitsfotografie Tirol", "Wedding getting ready – Wedding photography Tyrol"),
  w("getting-ready", "https://ik.imagekit.io/r2yqrg6np/Wedding/Getting%20Ready/20251004_8D2A0409_(WebRes).jpg?updatedAt=1773002917878", "Brautvorbereitung – Hochzeitsfotograf Innsbruck", "Bridal preparation – Wedding photographer Innsbruck"),
  w("getting-ready", "https://ik.imagekit.io/r2yqrg6np/Wedding/Getting%20Ready/20251004_8D2A0308_(WebRes).jpg?updatedAt=1773002917835", "Getting Ready Momente – Hochzeitsfotografie Alpen", "Getting ready moments – Alpine wedding photography"),
  w("getting-ready", "https://ik.imagekit.io/r2yqrg6np/Wedding/Getting%20Ready/20251004_8D2A0492_(WebRes).jpg?updatedAt=1773002917820", "Braut Vorbereitung – Hochzeitsfotograf Mario Schubert", "Bride preparation – Wedding photographer Mario Schubert"),
  w("getting-ready", "https://ik.imagekit.io/r2yqrg6np/Wedding/Getting%20Ready/20251004_8D2A0440_(WebRes).jpg?updatedAt=1773002917818", "Getting Ready – Hochzeitsfotografie Bayern Tirol", "Getting ready – Wedding photography Bavaria Tyrol"),
  w("getting-ready", "https://ik.imagekit.io/r2yqrg6np/Wedding/Getting%20Ready/20251004_8D2A0047_(WebRes).jpg?updatedAt=1773002917819", "Hochzeit Vorbereitung – Hochzeitsfotograf Innsbruck", "Wedding preparation – Wedding photographer Innsbruck"),
  w("getting-ready", "https://ik.imagekit.io/r2yqrg6np/Wedding/Getting%20Ready/20251004_8D2A0370_(WebRes).jpg?updatedAt=1773002917802", "Getting Ready Braut – Hochzeitsfotografie Tirol", "Getting ready bride – Wedding photography Tyrol"),
  w("getting-ready", "https://ik.imagekit.io/r2yqrg6np/Wedding/Getting%20Ready/20251004_8D2A0145_(WebRes).jpg?updatedAt=1773002917787", "Braut Getting Ready Details – Mario Schubert", "Bride getting ready details – Mario Schubert"),
  w("getting-ready", "https://ik.imagekit.io/r2yqrg6np/Wedding/Getting%20Ready/20251004_8D2A0419_(WebRes).jpg?updatedAt=1773002917721", "Getting Ready Emotionen – Hochzeitsfotograf Tirol", "Getting ready emotions – Wedding photographer Tyrol"),
  w("getting-ready", "https://ik.imagekit.io/r2yqrg6np/Wedding/Getting%20Ready/20251004_8D2A0361_(WebRes).jpg?updatedAt=1773002917543", "Hochzeit Vorbereitung – Hochzeitsfotografie Innsbruck", "Wedding preparation – Wedding photography Innsbruck"),
  w("getting-ready", "https://ik.imagekit.io/r2yqrg6np/Wedding/Getting%20Ready/20251004_8D2A0496_(WebRes).jpg?updatedAt=1773002917543", "Getting Ready – Hochzeitsfotograf Mario Schubert Tirol", "Getting ready – Wedding photographer Mario Schubert Tyrol"),
  w("getting-ready", "https://ik.imagekit.io/r2yqrg6np/Wedding/Getting%20Ready/20251004_8D2A0079_(WebRes).jpg?updatedAt=1773002917507", "Braut Vorbereitung Hochzeit – Fotograf Innsbruck", "Bride wedding preparation – Photographer Innsbruck"),
  w("getting-ready", "https://ik.imagekit.io/r2yqrg6np/Wedding/Getting%20Ready/20251004_8D2A0221_(WebRes).jpg?updatedAt=1773002917508", "Getting Ready Hochzeit Innsbruck – Hochzeitsfotografie", "Getting ready wedding Innsbruck – Wedding photography"),
  w("getting-ready", "https://ik.imagekit.io/r2yqrg6np/Wedding/Getting%20Ready/20251004_8D2A0168_(WebRes).jpg?updatedAt=1773002917499", "Hochzeit Getting Ready – Hochzeitsfotograf Tirol Bayern", "Wedding getting ready – Wedding photographer Tyrol Bavaria"),
  w("getting-ready", "https://ik.imagekit.io/r2yqrg6np/Wedding/Getting%20Ready/20251004_8D2A0297_(WebRes).jpg?updatedAt=1773002917396", "Getting Ready Braut – Mario Schubert Fotografie", "Getting ready bride – Mario Schubert Photography"),
  w("getting-ready", "https://ik.imagekit.io/r2yqrg6np/Wedding/Getting%20Ready/20251004_8D2A0471_(WebRes).jpg?updatedAt=1773002917374", "Brautvorbereitung – Hochzeitsfotografie Alpen Tirol", "Bridal preparation – Alpine wedding photography Tyrol"),
  w("getting-ready", "https://ik.imagekit.io/r2yqrg6np/Wedding/Getting%20Ready/20251004_8D2A0163_(WebRes).jpg?updatedAt=1773002917190", "Getting Ready Details – Hochzeitsfotograf Innsbruck", "Getting ready details – Wedding photographer Innsbruck"),
  w("getting-ready", "https://ik.imagekit.io/r2yqrg6np/Wedding/Getting%20Ready/20251004_8D2A0139_(WebRes).jpg?updatedAt=1773002917089", "Hochzeit Vorbereitung – Hochzeitsfotografie Mario Schubert", "Wedding preparation – Mario Schubert Photography"),
  w("getting-ready", "https://ik.imagekit.io/r2yqrg6np/Wedding/Getting%20Ready/20251004_8D2A0067_(WebRes).jpg?updatedAt=1773002916588", "Getting Ready – Hochzeitsfotograf Mario Schubert Innsbruck", "Getting ready – Wedding photographer Mario Schubert Innsbruck"),
  w("getting-ready", "https://ik.imagekit.io/r2yqrg6np/Wedding/Getting%20Ready/20251004_8D2A0113_(WebRes).jpg?updatedAt=1773002916557", "Braut Getting Ready – Hochzeitsfotografie Innsbruck Tirol", "Bride getting ready – Wedding photography Innsbruck Tyrol"),
  w("getting-ready", "https://ik.imagekit.io/r2yqrg6np/Wedding/Getting%20Ready/20251004_8D2A0483_(WebRes).jpg?updatedAt=1773002916487", "Getting Ready Emotionen – Hochzeitsfotografie Tirol", "Getting ready emotions – Wedding photography Tyrol"),
  w("getting-ready", "https://ik.imagekit.io/r2yqrg6np/Wedding/Getting%20Ready/20251004_8D2A0042_(WebRes).jpg?updatedAt=1773002914934", "Hochzeit Getting Ready – Hochzeitsfotograf Innsbruck Tirol", "Wedding getting ready – Wedding photographer Innsbruck Tyrol"),

  // ═══════════════════════════════════════════════
  // HOCHZEIT – Kirchliche Trauung (53 Bilder)
  // ═══════════════════════════════════════════════
  w("kirchliche-trauung", "https://ik.imagekit.io/r2yqrg6np/Wedding/kirchliche%20Trauung/250607_BobanElena_MidRes_0158.jpg?updatedAt=1773003722025", "Kirchliche Trauung – Hochzeitsfotografie Innsbruck", "Church ceremony – Wedding photography Innsbruck"),
  w("kirchliche-trauung", "https://ik.imagekit.io/r2yqrg6np/Wedding/kirchliche%20Trauung/250607_BobanElena_MidRes_0191.jpg?updatedAt=1773003721836", "Kirchliche Hochzeit – Hochzeitsfotograf Tirol", "Church wedding – Wedding photographer Tyrol"),
  w("kirchliche-trauung", "https://ik.imagekit.io/r2yqrg6np/Wedding/kirchliche%20Trauung/250607_BobanElena_MidRes_0138.jpg?updatedAt=1773003721751", "Trauung in der Kirche – Mario Schubert Fotografie", "Church ceremony – Mario Schubert Photography"),
  w("kirchliche-trauung", "https://ik.imagekit.io/r2yqrg6np/Wedding/kirchliche%20Trauung/250607_BobanElena_MidRes_0293.jpg?updatedAt=1773003721528", "Kirchliche Trauung Tirol – Hochzeitsfotografie Alpen", "Church ceremony Tyrol – Alpine wedding photography"),
  w("kirchliche-trauung", "https://ik.imagekit.io/r2yqrg6np/Wedding/kirchliche%20Trauung/250607_BobanElena_MidRes_0251.jpg?updatedAt=1773003721533", "Hochzeit Kirche – Hochzeitsfotograf Innsbruck Tirol", "Church wedding – Wedding photographer Innsbruck Tirol"),
  w("kirchliche-trauung", "https://ik.imagekit.io/r2yqrg6np/Wedding/kirchliche%20Trauung/250607_BobanElena_MidRes_0278.jpg?updatedAt=1773003721450", "Kirchliche Zeremonie – Hochzeitsfotografie Bayern", "Church ceremony – Wedding photography Bavaria"),
  w("kirchliche-trauung", "https://ik.imagekit.io/r2yqrg6np/Wedding/kirchliche%20Trauung/250607_BobanElena_MidRes_0283.jpg?updatedAt=1773003721352", "Trauung Kirche – Hochzeitsfotograf Mario Schubert", "Church ceremony – Wedding photographer Mario Schubert"),
  w("kirchliche-trauung", "https://ik.imagekit.io/r2yqrg6np/Wedding/kirchliche%20Trauung/250607_BobanElena_MidRes_0276.jpg?updatedAt=1773003721438", "Kirchliche Hochzeit Innsbruck – Hochzeitsfotografie", "Church wedding Innsbruck – Wedding photography"),
  w("kirchliche-trauung", "https://ik.imagekit.io/r2yqrg6np/Wedding/kirchliche%20Trauung/250607_BobanElena_MidRes_0141.jpg?updatedAt=1773003721240", "Kirchliche Trauung – Hochzeitsfotograf Tirol Bayern", "Church ceremony – Wedding photographer Tyrol Bavaria"),
  w("kirchliche-trauung", "https://ik.imagekit.io/r2yqrg6np/Wedding/kirchliche%20Trauung/250607_BobanElena_MidRes_0247.jpg?updatedAt=1773003721264", "Hochzeit in der Kirche – Hochzeitsfotografie Innsbruck", "Church wedding – Wedding photography Innsbruck"),
  w("kirchliche-trauung", "https://ik.imagekit.io/r2yqrg6np/Wedding/kirchliche%20Trauung/250607_BobanElena_MidRes_0151.jpg?updatedAt=1773003721196", "Kirchliche Zeremonie Tirol – Mario Schubert Fotografie", "Church ceremony Tyrol – Mario Schubert Photography"),
  w("kirchliche-trauung", "https://ik.imagekit.io/r2yqrg6np/Wedding/kirchliche%20Trauung/250607_BobanElena_MidRes_0241.jpg?updatedAt=1773003721070", "Kirchliche Trauung – Hochzeitsfotograf Innsbruck", "Church ceremony – Wedding photographer Innsbruck"),
  w("kirchliche-trauung", "https://ik.imagekit.io/r2yqrg6np/Wedding/kirchliche%20Trauung/250607_BobanElena_MidRes_0257.jpg?updatedAt=1773003720985", "Hochzeit Kirche Tirol – Hochzeitsfotografie Alpen", "Church wedding Tyrol – Alpine wedding photography"),
  w("kirchliche-trauung", "https://ik.imagekit.io/r2yqrg6np/Wedding/kirchliche%20Trauung/250607_BobanElena_MidRes_0140.jpg?updatedAt=1773003720764", "Kirchliche Trauung – Hochzeitsfotografie Mario Schubert", "Church ceremony – Mario Schubert Photography"),
  w("kirchliche-trauung", "https://ik.imagekit.io/r2yqrg6np/Wedding/kirchliche%20Trauung/250607_BobanElena_MidRes_0183.jpg?updatedAt=1773003720729", "Trauung Kirche Innsbruck – Hochzeitsfotograf Tirol", "Church ceremony Innsbruck – Wedding photographer Tyrol"),
  w("kirchliche-trauung", "https://ik.imagekit.io/r2yqrg6np/Wedding/kirchliche%20Trauung/250607_BobanElena_MidRes_0148.jpg?updatedAt=1773003720698", "Kirchliche Hochzeit – Hochzeitsfotografie Bayern Tirol", "Church wedding – Wedding photography Bavaria Tyrol"),
  w("kirchliche-trauung", "https://ik.imagekit.io/r2yqrg6np/Wedding/kirchliche%20Trauung/250607_BobanElena_MidRes_0146.jpg?updatedAt=1773003720606", "Kirchliche Zeremonie – Hochzeitsfotograf Innsbruck Tirol", "Church ceremony – Wedding photographer Innsbruck Tyrol"),
  w("kirchliche-trauung", "https://ik.imagekit.io/r2yqrg6np/Wedding/kirchliche%20Trauung/250607_BobanElena_MidRes_0311.jpg?updatedAt=1773003720592", "Kirchliche Trauung Alpen – Mario Schubert Fotografie", "Church ceremony Alps – Mario Schubert Photography"),
  w("kirchliche-trauung", "https://ik.imagekit.io/r2yqrg6np/Wedding/kirchliche%20Trauung/250607_BobanElena_MidRes_0243.jpg?updatedAt=1773003720505", "Hochzeit Kirche – Hochzeitsfotografie Innsbruck Tirol", "Church wedding – Wedding photography Innsbruck Tyrol"),
  w("kirchliche-trauung", "https://ik.imagekit.io/r2yqrg6np/Wedding/kirchliche%20Trauung/250607_BobanElena_MidRes_0331.jpg?updatedAt=1773003720501", "Kirchliche Trauung – Hochzeitsfotograf Mario Schubert Tirol", "Church ceremony – Wedding photographer Mario Schubert Tyrol"),
  w("kirchliche-trauung", "https://ik.imagekit.io/r2yqrg6np/Wedding/kirchliche%20Trauung/250607_BobanElena_MidRes_0166.jpg?updatedAt=1773003720447", "Kirchliche Zeremonie Innsbruck – Hochzeitsfotografie", "Church ceremony Innsbruck – Wedding photography"),
  w("kirchliche-trauung", "https://ik.imagekit.io/r2yqrg6np/Wedding/kirchliche%20Trauung/250607_BobanElena_MidRes_0130.jpg?updatedAt=1773003720264", "Kirchliche Hochzeit Tirol – Hochzeitsfotograf Innsbruck", "Church wedding Tyrol – Wedding photographer Innsbruck"),
  w("kirchliche-trauung", "https://ik.imagekit.io/r2yqrg6np/Wedding/kirchliche%20Trauung/250607_BobanElena_MidRes_0215.jpg?updatedAt=1773003720005", "Trauung in der Kirche – Hochzeitsfotografie Alpen", "Church ceremony – Alpine wedding photography"),
  w("kirchliche-trauung", "https://ik.imagekit.io/r2yqrg6np/Wedding/kirchliche%20Trauung/250607_BobanElena_MidRes_0249.jpg?updatedAt=1773003719633", "Kirchliche Trauung Bayern – Hochzeitsfotograf Mario Schubert", "Church ceremony Bavaria – Wedding photographer Mario Schubert"),
  w("kirchliche-trauung", "https://ik.imagekit.io/r2yqrg6np/Wedding/kirchliche%20Trauung/250607_BobanElena_MidRes_0168.jpg?updatedAt=1773003719525", "Kirchliche Hochzeit – Hochzeitsfotografie Innsbruck", "Church wedding – Wedding photography Innsbruck"),
  w("kirchliche-trauung", "https://ik.imagekit.io/r2yqrg6np/Wedding/kirchliche%20Trauung/250607_BobanElena_MidRes_0144.jpg?updatedAt=1773003719437", "Kirchliche Zeremonie – Hochzeitsfotograf Tirol Innsbruck", "Church ceremony – Wedding photographer Tyrol Innsbruck"),
  w("kirchliche-trauung", "https://ik.imagekit.io/r2yqrg6np/Wedding/kirchliche%20Trauung/250607_BobanElena_MidRes_0145.jpg?updatedAt=1773003719259", "Kirchliche Trauung – Hochzeitsfotografie Mario Schubert Tirol", "Church ceremony – Mario Schubert Photography Tyrol"),
  w("kirchliche-trauung", "https://ik.imagekit.io/r2yqrg6np/Wedding/kirchliche%20Trauung/250607_BobanElena_MidRes_0180.jpg?updatedAt=1773003719253", "Hochzeit Kirche Innsbruck – Hochzeitsfotograf Tirol", "Church wedding Innsbruck – Wedding photographer Tyrol"),
  w("kirchliche-trauung", "https://ik.imagekit.io/r2yqrg6np/Wedding/kirchliche%20Trauung/250607_BobanElena_MidRes_0162.jpg?updatedAt=1773003719134", "Kirchliche Trauung Tirol Bayern – Hochzeitsfotografie", "Church ceremony Tyrol Bavaria – Wedding photography"),
  w("kirchliche-trauung", "https://ik.imagekit.io/r2yqrg6np/Wedding/kirchliche%20Trauung/250607_BobanElena_MidRes_0160.jpg?updatedAt=1773003718985", "Kirchliche Zeremonie Alpen – Hochzeitsfotograf Innsbruck", "Church ceremony Alps – Wedding photographer Innsbruck"),
  w("kirchliche-trauung", "https://ik.imagekit.io/r2yqrg6np/Wedding/kirchliche%20Trauung/250607_BobanElena_MidRes_0188.jpg?updatedAt=1773003718332", "Kirchliche Hochzeit Innsbruck – Mario Schubert Fotografie", "Church wedding Innsbruck – Mario Schubert Photography"),
  w("kirchliche-trauung", "https://ik.imagekit.io/r2yqrg6np/Wedding/kirchliche%20Trauung/250607_BobanElena_MidRes_0271.jpg?updatedAt=1773003718200", "Kirchliche Trauung – Hochzeitsfotograf Innsbruck Bayern", "Church ceremony – Wedding photographer Innsbruck Bavaria"),
  w("kirchliche-trauung", "https://ik.imagekit.io/r2yqrg6np/Wedding/kirchliche%20Trauung/250607_BobanElena_MidRes_0265.jpg?updatedAt=1773003718033", "Trauung Kirche – Hochzeitsfotografie Tirol Innsbruck", "Church ceremony – Wedding photography Tyrol Innsbruck"),
  w("kirchliche-trauung", "https://ik.imagekit.io/r2yqrg6np/Wedding/kirchliche%20Trauung/250607_BobanElena_MidRes_0260.jpg?updatedAt=1773003717528", "Kirchliche Hochzeit – Hochzeitsfotograf Tirol Alpen", "Church wedding – Wedding photographer Tyrol Alps"),
  w("kirchliche-trauung", "https://ik.imagekit.io/r2yqrg6np/Wedding/kirchliche%20Trauung/250607_BobanElena_MidRes_0195.jpg?updatedAt=1773003716992", "Kirchliche Zeremonie – Hochzeitsfotografie Mario Schubert", "Church ceremony – Mario Schubert Photography"),
  w("kirchliche-trauung", "https://ik.imagekit.io/r2yqrg6np/Wedding/kirchliche%20Trauung/250607_BobanElena_MidRes_0136.jpg?updatedAt=1773003716935", "Kirchliche Trauung Innsbruck – Hochzeitsfotograf Tirol", "Church ceremony Innsbruck – Wedding photographer Tyrol"),
  w("kirchliche-trauung", "https://ik.imagekit.io/r2yqrg6np/Wedding/kirchliche%20Trauung/250607_BobanElena_MidRes_0255.jpg?updatedAt=1773003716752", "Hochzeit Kirche Tirol – Hochzeitsfotografie Bayern", "Church wedding Tyrol – Wedding photography Bavaria"),
  w("kirchliche-trauung", "https://ik.imagekit.io/r2yqrg6np/Wedding/kirchliche%20Trauung/250607_BobanElena_MidRes_0156.jpg?updatedAt=1773003716727", "Kirchliche Trauung – Hochzeitsfotograf Mario Schubert Innsbruck", "Church ceremony – Wedding photographer Mario Schubert Innsbruck"),
  w("kirchliche-trauung", "https://ik.imagekit.io/r2yqrg6np/Wedding/kirchliche%20Trauung/250607_BobanElena_MidRes_0128.jpg?updatedAt=1773003716684", "Kirchliche Zeremonie Tirol – Hochzeitsfotografie Innsbruck", "Church ceremony Tyrol – Wedding photography Innsbruck"),
  w("kirchliche-trauung", "https://ik.imagekit.io/r2yqrg6np/Wedding/kirchliche%20Trauung/250607_BobanElena_MidRes_0114.jpg?updatedAt=1773003716572", "Kirchliche Hochzeit Alpen – Hochzeitsfotograf Innsbruck Tirol", "Church wedding Alps – Wedding photographer Innsbruck Tyrol"),
  w("kirchliche-trauung", "https://ik.imagekit.io/r2yqrg6np/Wedding/kirchliche%20Trauung/250607_BobanElena_MidRes_0274.jpg?updatedAt=1773003716207", "Kirchliche Trauung – Hochzeitsfotografie Alpen Tirol", "Church ceremony – Alpine wedding photography Tyrol"),
  w("kirchliche-trauung", "https://ik.imagekit.io/r2yqrg6np/Wedding/kirchliche%20Trauung/250607_BobanElena_MidRes_0284.jpg?updatedAt=1773003716176", "Kirchliche Zeremonie – Hochzeitsfotograf Innsbruck", "Church ceremony – Wedding photographer Innsbruck"),
  w("kirchliche-trauung", "https://ik.imagekit.io/r2yqrg6np/Wedding/kirchliche%20Trauung/250607_BobanElena_MidRes_0121.jpg?updatedAt=1773003714826", "Hochzeit in der Kirche Tirol – Hochzeitsfotografie", "Church wedding Tyrol – Wedding photography"),
  w("kirchliche-trauung", "https://ik.imagekit.io/r2yqrg6np/Wedding/kirchliche%20Trauung/250607_BobanElena_MidRes_0111.jpg?updatedAt=1773003714285", "Kirchliche Trauung – Hochzeitsfotograf Tirol Alpen", "Church ceremony – Wedding photographer Tyrol Alps"),
  w("kirchliche-trauung", "https://ik.imagekit.io/r2yqrg6np/Wedding/kirchliche%20Trauung/250607_BobanElena_MidRes_0113.jpg?updatedAt=1773003713992", "Kirchliche Hochzeit – Mario Schubert Fotografie Innsbruck", "Church wedding – Mario Schubert Photography Innsbruck"),
  w("kirchliche-trauung", "https://ik.imagekit.io/r2yqrg6np/Wedding/kirchliche%20Trauung/250607_BobanElena_MidRes_0277.jpg?updatedAt=1773003713718", "Kirchliche Zeremonie Innsbruck – Hochzeitsfotograf Tirol", "Church ceremony Innsbruck – Wedding photographer Tyrol"),
  w("kirchliche-trauung", "https://ik.imagekit.io/r2yqrg6np/Wedding/kirchliche%20Trauung/250607_BobanElena_MidRes_0279.jpg?updatedAt=1773003713251", "Kirchliche Trauung Bayern – Hochzeitsfotografie Tirol", "Church ceremony Bavaria – Wedding photography Tyrol"),
  w("kirchliche-trauung", "https://ik.imagekit.io/r2yqrg6np/Wedding/kirchliche%20Trauung/250607_BobanElena_MidRes_0212.jpg?updatedAt=1773003712570", "Hochzeit Kirche – Hochzeitsfotograf Mario Schubert Tirol", "Church wedding – Wedding photographer Mario Schubert Tyrol"),
  w("kirchliche-trauung", "https://ik.imagekit.io/r2yqrg6np/Wedding/kirchliche%20Trauung/250607_BobanElena_MidRes_0217.jpg?updatedAt=1773003711300", "Kirchliche Trauung Innsbruck Tirol – Hochzeitsfotografie Alpen", "Church ceremony Innsbruck Tyrol – Alpine wedding photography"),
  w("kirchliche-trauung", "https://ik.imagekit.io/r2yqrg6np/Wedding/kirchliche%20Trauung/250607_BobanElena_MidRes_0165.jpg?updatedAt=1773003711293", "Kirchliche Zeremonie – Hochzeitsfotografie Innsbruck Tirol", "Church ceremony – Wedding photography Innsbruck Tyrol"),
  w("kirchliche-trauung", "https://ik.imagekit.io/r2yqrg6np/Wedding/kirchliche%20Trauung/250607_BobanElena_MidRes_0246.jpg?updatedAt=1773003710660", "Kirchliche Hochzeit – Hochzeitsfotograf Innsbruck Bayern", "Church wedding – Wedding photographer Innsbruck Bavaria"),
  w("kirchliche-trauung", "https://ik.imagekit.io/r2yqrg6np/Wedding/kirchliche%20Trauung/250607_BobanElena_MidRes_0264.jpg?updatedAt=1773003710254", "Kirchliche Trauung Tirol – Hochzeitsfotograf Mario Schubert", "Church ceremony Tyrol – Wedding photographer Mario Schubert"),
  w("kirchliche-trauung", "https://ik.imagekit.io/r2yqrg6np/Wedding/kirchliche%20Trauung/250607_BobanElena_MidRes_0266.jpg?updatedAt=1773003710022", "Kirchliche Zeremonie Alpen – Hochzeitsfotografie Tirol Innsbruck", "Church ceremony Alps – Wedding photography Tyrol Innsbruck"),

  // ═══════════════════════════════════════════════
  // HOCHZEIT – Paarshooting (8 Fallback-Bilder)
  // ═══════════════════════════════════════════════
  w("paarshooting", "https://images.unsplash.com/photo-1680818508921-844425951e45?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb3VwbGUlMjBwb3J0cmFpdCUyMG1vdW50YWluJTIwZ29sZGVuJTIwaG91cnxlbnwxfHx8fDE3NzMwMTQwMjl8MA&ixlib=rb-4.1.0&q=80&w=1080", "Romantisches Paarshooting in den Bergen – Hochzeitsfotograf Innsbruck", "Romantic couple shoot in the mountains – Wedding photographer Innsbruck"),
  w("paarshooting", "https://images.unsplash.com/photo-1758565177415-33b15a0729de?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb3VwbGUlMjB3YWxraW5nJTIwdG9nZXRoZXIlMjByb21hbnRpYyUyMGZpZWxkfGVufDF8fHx8MTc3MzAxNDAzNHww&ixlib=rb-4.1.0&q=80&w=1080", "Paarshooting bei Sonnenuntergang – Paarfotografie Tirol", "Couple shoot at sunset – Couple photography Tyrol"),
  w("paarshooting", "https://images.unsplash.com/photo-1758524053982-dc0fc7cd651f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb3VwbGUlMjBsYXVnaGluZyUyMG91dGRvb3IlMjBuYXR1cmFsfGVufDF8fHx8MTc3MzAxNDAzNXww&ixlib=rb-4.1.0&q=80&w=1080", "Lachendes Paar beim Outdoor-Shooting – Hochzeitsfotografie Tirol", "Laughing couple during outdoor shoot – Wedding photography Tyrol"),
  w("paarshooting", "https://images.unsplash.com/photo-1514846528774-8de9d4a07023?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb3VwbGUlMjBlbWJyYWNlJTIwcm9tYW50aWMlMjBvdXRkb29yfGVufDF8fHx8MTc3MzAxNDAzMHww&ixlib=rb-4.1.0&q=80&w=1080", "Romantische Umarmung – Paarshooting Innsbruck Tirol", "Romantic embrace – Couple shoot Innsbruck Tyrol"),
  w("paarshooting", "https://images.unsplash.com/photo-1758810410699-2dc1daec82dc?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxyb21hbnRpYyUyMGNvdXBsZSUyMHN1bnNldCUyMHNpbGhvdWV0dGV8ZW58MXx8fHwxNzcyOTY2ODY5fDA&ixlib=rb-4.1.0&q=80&w=1080", "Paar-Silhouette bei Sonnenuntergang – Hochzeitsfotograf Bayern", "Couple silhouette at sunset – Wedding photographer Bavaria"),
  w("paarshooting", "https://images.unsplash.com/photo-1662049659925-6a732fc2909c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb3VwbGUlMjBraXNzJTIwbW91bnRhaW4lMjBsYW5kc2NhcGV8ZW58MXx8fHwxNzczMDE0MDM4fDA&ixlib=rb-4.1.0&q=80&w=1080", "Kuss in den Bergen – Paarshooting Alpen Mario Schubert", "Kiss in the mountains – Couple shoot Alps Mario Schubert"),
  w("paarshooting", "https://images.unsplash.com/photo-1769050349380-7ee061d43ef9?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb3VwbGUlMjBwb3J0cmFpdCUyMHN1bnNldCUyMHJvbWFudGljJTIwb3V0ZG9vcnN8ZW58MXx8fHwxNzcyOTk3NTMzfDA&ixlib=rb-4.1.0&q=80&w=1080", "Paarportrait bei Sonnenuntergang – Paarfotografie Tirol Bayern", "Couple portrait at sunset – Couple photography Tyrol Bavaria"),
  w("paarshooting", "https://images.unsplash.com/photo-1768468104186-368aeb7a266a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb3VwbGUlMjBsYXVnaGluZyUyMG91dGRvb3IlMjBlbmdhZ2VtZW50JTIwcGhvdG98ZW58MXx8fHwxNzcyOTk3NTM0fDA&ixlib=rb-4.1.0&q=80&w=1080", "Lachendes Paar beim Engagement-Shooting – Hochzeitsfotograf Innsbruck", "Laughing couple at engagement shoot – Wedding photographer Innsbruck"),

  // ═══════════════════════════════════════════════
  // HOCHZEIT – Freie Trauung (6 Fallback-Bilder)
  // ═══════════════════════════════════════════════
  w("freie-trauung", "https://images.unsplash.com/photo-1696271026740-4c0c1a367f03?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxvdXRkb29yJTIwd2VkZGluZyUyMGNlcmVtb255JTIwbmF0dXJlfGVufDF8fHx8MTc3MzAxNDAyOXww&ixlib=rb-4.1.0&q=80&w=1080", "Freie Trauung Outdoor – Hochzeitsfotografie Tirol", "Outdoor ceremony – Wedding photography Tyrol"),
  w("freie-trauung", "https://images.unsplash.com/photo-1763560836989-d3636e2f82d8?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxvdXRkb29yJTIwd2VkZGluZyUyMGNlcmVtb255JTIwYXJjaCUyMGZsb3dlcnN8ZW58MXx8fHwxNzczMDE0MDMwfDA&ixlib=rb-4.1.0&q=80&w=1080", "Freie Trauung mit Blumenbogen – Hochzeitsfotograf Innsbruck", "Outdoor ceremony with flower arch – Wedding photographer Innsbruck"),
  w("freie-trauung", "https://images.unsplash.com/photo-1677677403344-029c7fcd7300?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx3ZWRkaW5nJTIwb3V0ZG9vciUyMGNlcmVtb255JTIwcnVzdGljfGVufDF8fHx8MTc3MzAxNDAzNnww&ixlib=rb-4.1.0&q=80&w=1080", "Rustikale freie Trauung – Hochzeitsfotografie Bayern", "Rustic outdoor ceremony – Wedding photography Bavaria"),
  w("freie-trauung", "https://images.unsplash.com/photo-1740688055196-a836abca5518?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxvdXRkb29yJTIwY2VyZW1vbnklMjB3ZWRkaW5nJTIwdm93cyUyMG5hdHVyZXxlbnwxfHx8fDE3NzMwMTQwMzd8MA&ixlib=rb-4.1.0&q=80&w=1080", "Eheversprechen bei freier Trauung – Mario Schubert Fotografie", "Wedding vows at outdoor ceremony – Mario Schubert Photography"),
  w("freie-trauung", "https://images.unsplash.com/photo-1772404245508-3d9902599c07?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx3ZWRkaW5nJTIwY2VyZW1vbnklMjBvdXRkb29yJTIwZ2FyZGVuJTIwYWlzbGV8ZW58MXx8fHwxNzczMDE0MDMwfDA&ixlib=rb-4.1.0&q=80&w=1080", "Freie Trauung im Garten – Hochzeitsfotograf Tirol Alpen", "Garden ceremony – Wedding photographer Tyrol Alps"),
  w("freie-trauung", "https://images.unsplash.com/photo-1769812344337-ec16a1b7cef8?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx3ZWRkaW5nJTIwY2VyZW1vbnklMjBvdXRkb29yJTIwZWxlZ2FudHxlbnwxfHx8fDE3NzI5OTc1MzF8MA&ixlib=rb-4.1.0&q=80&w=1080", "Elegante freie Trauung Outdoor – Hochzeitsfotografie Innsbruck", "Elegant outdoor ceremony – Wedding photography Innsbruck"),

  // ═══════════════════════════════════════════════
  // HOCHZEIT – Abend-Party (8 Fallback-Bilder, ImageKit: /Wedding/Abend-Party → category "party")
  // ═══════════════════════════════════════════════
  w("party", "https://images.unsplash.com/photo-1764269719300-7094d6c00533?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx3ZWRkaW5nJTIwcGFydHklMjBjZWxlYnJhdGlvbiUyMGRhbmNlfGVufDF8fHx8MTc3MzAxNDAyOXww&ixlib=rb-4.1.0&q=80&w=1080", "Hochzeitsparty – Feier und Tanz – Hochzeitsfotograf Innsbruck", "Wedding party – Celebration and dance – Wedding photographer Innsbruck"),
  w("party", "https://images.unsplash.com/photo-1765615201173-0ea7dcadc4bb?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx3ZWRkaW5nJTIwcmVjZXB0aW9uJTIwcGFydHklMjBndWVzdHMlMjBkYW5jaW5nfGVufDF8fHx8MTc3MzAxNDAzMHww&ixlib=rb-4.1.0&q=80&w=1080", "Hochzeitsempfang – Gäste tanzen – Hochzeitsfotografie Tirol", "Wedding reception – Guests dancing – Wedding photography Tyrol"),
  w("party", "https://images.unsplash.com/photo-1769230387364-8b0c2b63e18b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx3ZWRkaW5nJTIwY291cGxlJTIwZmlyc3QlMjBkYW5jZSUyMGxpZ2h0c3xlbnwxfHx8fDE3NzMwMTQwMzZ8MA&ixlib=rb-4.1.0&q=80&w=1080", "Erster Tanz – Hochzeitsfeier – Hochzeitsfotograf Mario Schubert", "First dance – Wedding celebration – Wedding photographer Mario Schubert"),
  w("party", "https://images.unsplash.com/photo-1768508948986-a0cb8a3ca83b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx3ZWRkaW5nJTIwdG9hc3QlMjBjZWxlYnJhdGlvbiUyMGV2ZW5pbmd8ZW58MXx8fHwxNzczMDE0MDMxfDA&ixlib=rb-4.1.0&q=80&w=1080", "Hochzeitstoast – Abendfeier – Hochzeitsfotografie Bayern", "Wedding toast – Evening celebration – Wedding photography Bavaria"),
  w("party", "https://images.unsplash.com/photo-1758810411894-3c0f092f305f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx3ZWRkaW5nJTIwZ3Vlc3RzJTIwY2VsZWJyYXRpb24lMjBjb25mZXR0aXxlbnwxfHx8fDE3NzMwMTQwMzd8MA&ixlib=rb-4.1.0&q=80&w=1080", "Konfetti-Regen – Hochzeitsfeier – Hochzeitsfotograf Tirol", "Confetti shower – Wedding celebration – Wedding photographer Tyrol"),
  w("party", "https://images.unsplash.com/photo-1758810409984-aba17272627b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx3ZWRkaW5nJTIwYm91cXVldCUyMHRvc3MlMjBjZWxlYnJhdGlvbnxlbnwxfHx8fDE3NzMwMTQwMzh8MA&ixlib=rb-4.1.0&q=80&w=1080", "Brautstraußwurf – Hochzeitsparty – Hochzeitsfotografie Innsbruck", "Bouquet toss – Wedding party – Wedding photography Innsbruck"),
  w("party", "https://images.unsplash.com/photo-1633978555421-1e67d524b227?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx3ZWRkaW5nJTIwZGFuY2UlMjBmaXJzdCUyMHJlY2VwdGlvbnxlbnwxfHx8fDE3NzI5OTU3OTR8MA&ixlib=rb-4.1.0&q=80&w=1080", "Erster Tanz bei der Hochzeitsfeier – Hochzeitsfotograf Bayern Tirol", "First dance at wedding reception – Wedding photographer Bavaria Tyrol"),
  w("party", "https://images.unsplash.com/photo-1704455308461-1e18a7e11d28?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx3ZWRkaW5nJTIwY291cGxlJTIwZmlyc3QlMjBkYW5jZSUyMHJlY2VwdGlvbnxlbnwxfHx8fDE3NzI5OTc1MzJ8MA&ixlib=rb-4.1.0&q=80&w=1080", "Hochzeitstanz – Hochzeitsfeier – Mario Schubert Fotografie Innsbruck", "Wedding dance – Wedding reception – Mario Schubert Photography Innsbruck"),
];

function getCachedData(): ImageEntry[] | null {
  try {
    const cached = localStorage.getItem(CACHE_KEY);
    if (!cached) return null;

    const { data, timestamp } = JSON.parse(cached);
    if (Date.now() - timestamp > CACHE_DURATION) {
      localStorage.removeItem(CACHE_KEY);
      return null;
    }

    // Don't use cache if it has suspiciously few images (stale/empty cache)
    if (!data || data.length < FALLBACK_IMAGES.length * 0.5) {
      localStorage.removeItem(CACHE_KEY);
      return null;
    }

    return data;
  } catch {
    return null;
  }
}

function setCachedData(data: ImageEntry[]) {
  try {
    localStorage.setItem(
      CACHE_KEY,
      JSON.stringify({ data, timestamp: Date.now() })
    );
  } catch {
    // localStorage might be full or unavailable
  }
}

/**
 * Clear the images localStorage cache.
 * Call this after a sync so new images are fetched on next load.
 */
export function clearImagesCache() {
  try {
    localStorage.removeItem(CACHE_KEY);
    // Set a cache-bust flag so the next fetch bypasses Vercel CDN
    localStorage.setItem(CACHE_BUST_KEY, String(Date.now()));
  } catch {
    // ignore
  }
}

/**
 * Main hook – fetches all images once, returns filtered helper.
 */
export function useImages() {
  const [state, setState] = useState<ImagesState>({
    images: FALLBACK_IMAGES,
    loading: true,
    error: null,
  });

  useEffect(() => {
    // Check cache first
    const cached = getCachedData();
    if (cached && cached.length > 0) {
      setState({ images: cached, loading: false, error: null });
      return;
    }

    let cancelled = false;

    async function fetchImages() {
      try {
        // Priority 1: Storyblok CMS
        if (isStoryblokConfigured()) {
          const sbImages = await fetchImagesFromStoryblok();
          if (sbImages && sbImages.length > 0 && !cancelled) {
            // Merge: Storyblok images take priority, fallback fills missing categories
            const sbCategories = new Set(
              sbImages.map((img: ImageEntry) => `${img.page}:${img.category}`)
            );
            const fallbackFill = FALLBACK_IMAGES.filter(
              (img) => !sbCategories.has(`${img.page}:${img.category}`)
            );
            const merged = [...sbImages, ...fallbackFill];
            console.log(`[useImages] Storyblok: ${sbImages.length} images + ${fallbackFill.length} fallback = ${merged.length} total`);
            setCachedData(merged);
            setState({ images: merged, loading: false, error: null });
            return;
          }
        }

        // Priority 2: Google Sheets API (legacy)
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), 8000);

        // Add cache-buster to bypass Vercel CDN cache (especially after sync)
        let apiUrl = "/api/get-images";
        try {
          const bustTs = localStorage.getItem(CACHE_BUST_KEY);
          if (bustTs) {
            apiUrl += `?_cb=${bustTs}`;
            // Clear the bust flag after using it once
            localStorage.removeItem(CACHE_BUST_KEY);
          }
        } catch {
          // localStorage unavailable
        }

        const response = await fetch(apiUrl, { signal: controller.signal });
        clearTimeout(timeoutId);

        if (!response.ok) throw new Error(`HTTP ${response.status}`);

        const data = await response.json();

        console.log(`[useImages] API response: ${data.images?.length ?? 0} images, source: ${data.source}`);

        if (!cancelled && data.images && data.images.length > 0) {
          // Merge: API images take priority, fallback fills missing categories
          const apiCategories = new Set(
            data.images.map((img: ImageEntry) => `${img.page}:${img.category}`)
          );
          const fallbackFill = FALLBACK_IMAGES.filter(
            (img) => !apiCategories.has(`${img.page}:${img.category}`)
          );
          const merged = [...data.images, ...fallbackFill];
          console.log(`[useImages] Merged: ${data.images.length} API + ${fallbackFill.length} fallback = ${merged.length} total`);
          setCachedData(merged);
          setState({ images: merged, loading: false, error: null });
        } else if (!cancelled) {
          // API returned empty – keep fallback
          console.warn("[useImages] API returned empty, keeping fallback data");
          setState((prev) => ({ ...prev, loading: false }));
        }
      } catch (err: any) {
        console.warn("[useImages] API failed, using fallback:", err.message);
        if (!cancelled) {
          setState((prev) => ({ ...prev, loading: false, error: err.message }));
        }
      }
    }

    fetchImages();

    return () => {
      cancelled = true;
    };
  }, []);

  /**
   * Filter images by page and optionally by category.
   * Returns { src, alt } objects ready for gallery rendering.
   */
  const getImagesForPage = useMemo(
    () =>
      (page: string, category?: string, lang: string = "de") => {
        return state.images
          .filter(
            (img) =>
              img.page === page.toLowerCase() &&
              (!category || img.category === category.toLowerCase())
          )
          .map((img) => ({
            src: img.src,
            alt: lang === "de" ? img.altDe : img.altEn,
            category: img.category,
          }));
      },
    [state.images]
  );

  return {
    ...state,
    getImagesForPage,
    allImages: state.images,
  };
}

// ── Storyblok image mapper ──

interface StoryblokGalleryContent {
  page: string;
  category: string;
  image_url: string;
  alt_de: string;
  alt_en: string;
  sort_order: number;
}

// ── Auto Alt-Tag Generator ──
// Generates SEO-optimized alt tags based on page + category if not manually set

const ALT_TEMPLATES: Record<string, { de: string[]; en: string[] }> = {
  "hochzeit:standesamt": {
    de: [
      "Standesamtliche Trauung \u2013 Hochzeitsfotografie Innsbruck",
      "Standesamt Hochzeit \u2013 Hochzeitsfotograf Tirol",
      "Standesamtliche Trauung \u2013 Mario Schubert Fotografie",
      "Standesamt Zeremonie \u2013 Hochzeitsfotograf Innsbruck Tirol",
      "Standesamt Hochzeitsfotografie \u2013 Mario Schubert Tirol",
    ],
    en: [
      "Civil ceremony \u2013 Wedding photography Innsbruck",
      "Civil wedding \u2013 Wedding photographer Tyrol",
      "Civil ceremony \u2013 Mario Schubert Photography",
      "Civil ceremony \u2013 Wedding photographer Innsbruck Tyrol",
      "Civil wedding photography \u2013 Mario Schubert Tyrol",
    ],
  },
  "hochzeit:getting-ready": {
    de: [
      "Getting Ready \u2013 Hochzeitsfotografie Innsbruck",
      "Braut Getting Ready \u2013 Hochzeitsfotograf Tirol",
      "Getting Ready Details \u2013 Mario Schubert Fotografie",
      "Hochzeit Vorbereitung \u2013 Hochzeitsfotograf Innsbruck",
      "Getting Ready Momente \u2013 Hochzeitsfotografie Tirol",
    ],
    en: [
      "Getting ready \u2013 Wedding photography Innsbruck",
      "Bride getting ready \u2013 Wedding photographer Tyrol",
      "Getting ready details \u2013 Mario Schubert Photography",
      "Wedding preparation \u2013 Wedding photographer Innsbruck",
      "Getting ready moments \u2013 Wedding photography Tyrol",
    ],
  },
  "hochzeit:kirchliche-trauung": {
    de: [
      "Kirchliche Trauung \u2013 Hochzeitsfotografie Innsbruck",
      "Kirchliche Hochzeit \u2013 Hochzeitsfotograf Tirol",
      "Trauung in der Kirche \u2013 Mario Schubert Fotografie",
      "Kirchliche Zeremonie \u2013 Hochzeitsfotografie Alpen",
      "Kirchliche Trauung Tirol \u2013 Hochzeitsfotograf Innsbruck",
    ],
    en: [
      "Church ceremony \u2013 Wedding photography Innsbruck",
      "Church wedding \u2013 Wedding photographer Tyrol",
      "Church ceremony \u2013 Mario Schubert Photography",
      "Church ceremony \u2013 Alpine wedding photography",
      "Church ceremony Tyrol \u2013 Wedding photographer Innsbruck",
    ],
  },
  "hochzeit:paarshooting": {
    de: [
      "Romantisches Paarshooting \u2013 Hochzeitsfotograf Innsbruck",
      "Paarshooting bei Sonnenuntergang \u2013 Paarfotografie Tirol",
      "Paar-Portrait in den Bergen \u2013 Mario Schubert Fotografie",
      "Hochzeit Paarshooting \u2013 Hochzeitsfotografie Tirol",
      "Couple Shooting \u2013 Hochzeitsfotograf Mario Schubert",
    ],
    en: [
      "Romantic couple shoot \u2013 Wedding photographer Innsbruck",
      "Couple shoot at sunset \u2013 Couple photography Tyrol",
      "Couple portrait in the mountains \u2013 Mario Schubert Photography",
      "Wedding couple shoot \u2013 Wedding photography Tyrol",
      "Couple shooting \u2013 Wedding photographer Mario Schubert",
    ],
  },
  "hochzeit:empfang": {
    de: [
      "Hochzeitsempfang \u2013 Hochzeitsfotografie Innsbruck",
      "Empfang & Feier \u2013 Hochzeitsfotograf Tirol",
      "Hochzeitsfeier \u2013 Mario Schubert Fotografie",
      "Empfang Hochzeit \u2013 Hochzeitsfotografie Tirol Bayern",
      "Hochzeitsempfang \u2013 Hochzeitsfotograf Mario Schubert",
    ],
    en: [
      "Wedding reception \u2013 Wedding photography Innsbruck",
      "Reception & celebration \u2013 Wedding photographer Tyrol",
      "Wedding celebration \u2013 Mario Schubert Photography",
      "Wedding reception \u2013 Wedding photography Tyrol Bavaria",
      "Wedding reception \u2013 Wedding photographer Mario Schubert",
    ],
  },
  "hochzeit:details": {
    de: [
      "Hochzeitsdetails \u2013 Hochzeitsfotografie Innsbruck",
      "Details & Dekoration \u2013 Hochzeitsfotograf Tirol",
      "Hochzeit Detailaufnahmen \u2013 Mario Schubert Fotografie",
      "Eheringe & Details \u2013 Hochzeitsfotografie Tirol",
      "Hochzeitsdetails \u2013 Hochzeitsfotograf Mario Schubert",
    ],
    en: [
      "Wedding details \u2013 Wedding photography Innsbruck",
      "Details & decoration \u2013 Wedding photographer Tyrol",
      "Wedding detail shots \u2013 Mario Schubert Photography",
      "Wedding rings & details \u2013 Wedding photography Tyrol",
      "Wedding details \u2013 Wedding photographer Mario Schubert",
    ],
  },
  "tiere:hunde": {
    de: [
      "Hundefotografie \u2013 Tierfotograf Innsbruck",
      "Hundeportrait \u2013 Tierfotografie Tirol",
      "Hundeshooting \u2013 Mario Schubert Fotografie",
      "Hundefotografie outdoor \u2013 Tierfotograf Tirol",
      "Hund Portrait \u2013 Tierfotografie Innsbruck",
    ],
    en: [
      "Dog photography \u2013 Animal photographer Innsbruck",
      "Dog portrait \u2013 Animal photography Tyrol",
      "Dog photo shoot \u2013 Mario Schubert Photography",
      "Outdoor dog photography \u2013 Animal photographer Tyrol",
      "Dog portrait \u2013 Animal photography Innsbruck",
    ],
  },
  "tiere:pferde": {
    de: [
      "Pferdefotografie \u2013 Tierfotograf Innsbruck",
      "Pferd & Mensch \u2013 Tierfotografie Tirol",
      "Pferdeportrait \u2013 Mario Schubert Fotografie",
      "Pferdeshooting \u2013 Tierfotograf Tirol",
      "Pferdefotografie outdoor \u2013 Tierfotografie Innsbruck",
    ],
    en: [
      "Horse photography \u2013 Animal photographer Innsbruck",
      "Horse & human \u2013 Animal photography Tyrol",
      "Horse portrait \u2013 Mario Schubert Photography",
      "Horse photo shoot \u2013 Animal photographer Tyrol",
      "Outdoor horse photography \u2013 Animal photography Innsbruck",
    ],
  },
  "tiere:andere": {
    de: [
      "Tierfotografie \u2013 Tierfotograf Innsbruck",
      "Haustier Portrait \u2013 Tierfotografie Tirol",
      "Tiershooting \u2013 Mario Schubert Fotografie",
      "Kleintier Fotografie \u2013 Tierfotograf Tirol",
      "Tierfotografie \u2013 Fotograf Innsbruck Tirol",
    ],
    en: [
      "Animal photography \u2013 Animal photographer Innsbruck",
      "Pet portrait \u2013 Animal photography Tyrol",
      "Pet photo shoot \u2013 Mario Schubert Photography",
      "Small animal photography \u2013 Animal photographer Tyrol",
      "Animal photography \u2013 Photographer Innsbruck Tyrol",
    ],
  },
  "portrait:couple": {
    de: [
      "Paarshooting \u2013 Fotograf Innsbruck",
      "Couple Shooting \u2013 Paarfotografie Tirol",
      "Paarportrait \u2013 Mario Schubert Fotografie",
      "Paarshooting outdoor \u2013 Fotograf Tirol",
      "Couple Portrait \u2013 Paarfotografie Innsbruck",
    ],
    en: [
      "Couple shoot \u2013 Photographer Innsbruck",
      "Couple shooting \u2013 Couple photography Tyrol",
      "Couple portrait \u2013 Mario Schubert Photography",
      "Outdoor couple shoot \u2013 Photographer Tyrol",
      "Couple portrait \u2013 Couple photography Innsbruck",
    ],
  },
  "portrait:familie": {
    de: [
      "Familienshooting \u2013 Fotograf Innsbruck",
      "Familienfotografie \u2013 Familienfotograf Tirol",
      "Familienportrait \u2013 Mario Schubert Fotografie",
      "Familie & Kinder \u2013 Fotograf Innsbruck Tirol",
      "Familienshooting outdoor \u2013 Familienfotografie Tirol",
    ],
    en: [
      "Family shoot \u2013 Photographer Innsbruck",
      "Family photography \u2013 Family photographer Tyrol",
      "Family portrait \u2013 Mario Schubert Photography",
      "Family & kids \u2013 Photographer Innsbruck Tyrol",
      "Outdoor family shoot \u2013 Family photography Tyrol",
    ],
  },
  "portrait:privat": {
    de: [
      "Eventfotografie \u2013 Fotograf Innsbruck",
      "Private Anl\u00e4sse \u2013 Fotografie Tirol",
      "Eventfotos \u2013 Mario Schubert Fotografie",
      "Geburtstag & Events \u2013 Fotograf Tirol",
      "Eventfotografie \u2013 Fotograf Innsbruck Tirol",
    ],
    en: [
      "Event photography \u2013 Photographer Innsbruck",
      "Private occasions \u2013 Photography Tyrol",
      "Event photos \u2013 Mario Schubert Photography",
      "Birthday & events \u2013 Photographer Tyrol",
      "Event photography \u2013 Photographer Innsbruck Tyrol",
    ],
  },
};

function generateGenericAlt(page: string, category: string, index: number): { de: string; en: string } {
  const pageMap: Record<string, { de: string; en: string }> = {
    hochzeit: { de: "Hochzeitsfotografie", en: "Wedding photography" },
    tiere: { de: "Tierfotografie", en: "Animal photography" },
    portrait: { de: "Portraitfotografie", en: "Portrait photography" },
  };
  const catMap: Record<string, { de: string; en: string }> = {
    standesamt: { de: "Standesamtliche Trauung", en: "Civil ceremony" },
    "getting-ready": { de: "Getting Ready", en: "Getting ready" },
    "kirchliche-trauung": { de: "Kirchliche Trauung", en: "Church ceremony" },
    paarshooting: { de: "Paarshooting", en: "Couple shoot" },
    empfang: { de: "Empfang & Feier", en: "Reception & celebration" },
    details: { de: "Hochzeitsdetails", en: "Wedding details" },
    hunde: { de: "Hundefotografie", en: "Dog photography" },
    pferde: { de: "Pferdefotografie", en: "Horse photography" },
    andere: { de: "Tierfotografie", en: "Animal photography" },
    couple: { de: "Paarshooting", en: "Couple shoot" },
    familie: { de: "Familienshooting", en: "Family shoot" },
    privat: { de: "Private Anl\u00e4sse", en: "Private occasions" },
  };
  const locations = ["Innsbruck", "Tirol", "Innsbruck Tirol", "Bayern", "Mario Schubert"];
  const location = locations[index % locations.length];
  const pageName = pageMap[page] || { de: "Fotografie", en: "Photography" };
  const catName = catMap[category] || { de: category, en: category };
  return {
    de: `${catName.de} \u2013 ${pageName.de} ${location}`,
    en: `${catName.en} \u2013 ${pageName.en} ${location}`,
  };
}

function autoGenerateAlt(page: string, category: string, index: number): { de: string; en: string } {
  const key = `${page}:${category}`;
  const templates = ALT_TEMPLATES[key];
  if (templates) {
    const i = index % templates.de.length;
    return { de: templates.de[i], en: templates.en[i] };
  }
  return generateGenericAlt(page, category, index);
}

async function fetchImagesFromStoryblok(): Promise<ImageEntry[] | null> {
  try {
    const stories = await fetchStoryblokStories<StoryblokGalleryContent>(
      "gallery/",
      "gallery_images"
    );

    if (!stories || stories.length === 0) return null;

    // Track index per page:category for alt-tag rotation
    const categoryCounters: Record<string, number> = {};

    return stories.map((s) => {
      const page = (s.content.page || "").toLowerCase();
      const category = (s.content.category || "").toLowerCase();
      const key = `${page}:${category}`;
      const idx = categoryCounters[key] || 0;
      categoryCounters[key] = idx + 1;

      // Use manual alt tags if provided, otherwise auto-generate
      const hasManualDe = s.content.alt_de && s.content.alt_de.trim().length > 0;
      const hasManualEn = s.content.alt_en && s.content.alt_en.trim().length > 0;
      const autoAlt = (!hasManualDe || !hasManualEn) ? autoGenerateAlt(page, category, idx) : null;

      return {
        page,
        category,
        src: s.content.image_url || "",
        altDe: hasManualDe ? s.content.alt_de : (autoAlt?.de || ""),
        altEn: hasManualEn ? s.content.alt_en : (autoAlt?.en || ""),
      };
    });
  } catch (err) {
    console.warn("[Storyblok] Failed to fetch gallery images:", err);
    return null;
  }
}